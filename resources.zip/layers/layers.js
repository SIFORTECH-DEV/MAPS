var wms_layers = [];


        var lyr_EsriSatellite_0 = new ol.layer.Tile({
            'title': 'Esri Satellite',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
            })
        });
var format_EXAMPLE_1 = new ol.format.GeoJSON();
var features_EXAMPLE_1 = format_EXAMPLE_1.readFeatures(json_EXAMPLE_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_EXAMPLE_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_EXAMPLE_1.addFeatures(features_EXAMPLE_1);
var lyr_EXAMPLE_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_EXAMPLE_1, 
                style: style_EXAMPLE_1,
                interactive: true,
                title: 'EXAMPLE'
            });
var format_PEXAMPLE_2 = new ol.format.GeoJSON();
var features_PEXAMPLE_2 = format_PEXAMPLE_2.readFeatures(json_PEXAMPLE_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PEXAMPLE_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PEXAMPLE_2.addFeatures(features_PEXAMPLE_2);
var lyr_PEXAMPLE_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PEXAMPLE_2, 
                style: style_PEXAMPLE_2,
                interactive: true,
                title: '<img src="styles/legend/PEXAMPLE_2.png" /> P.EXAMPLE'
            });

lyr_EsriSatellite_0.setVisible(true);lyr_EXAMPLE_1.setVisible(true);lyr_PEXAMPLE_2.setVisible(true);
var layersList = [lyr_EsriSatellite_0,lyr_EXAMPLE_1,lyr_PEXAMPLE_2];
lyr_EXAMPLE_1.set('fieldAliases', {'id': 'id', 'line name': 'line name', });
lyr_PEXAMPLE_2.set('fieldAliases', {'id': 'id', });
lyr_EXAMPLE_1.set('fieldImages', {'id': 'TextEdit', 'line name': 'TextEdit', });
lyr_PEXAMPLE_2.set('fieldImages', {'id': 'TextEdit', });
lyr_EXAMPLE_1.set('fieldLabels', {'id': 'no label', 'line name': 'no label', });
lyr_PEXAMPLE_2.set('fieldLabels', {'id': 'no label', });
lyr_PEXAMPLE_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});